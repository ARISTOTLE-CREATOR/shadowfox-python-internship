# ShadowFox Data Analyst Internship — Intermediate Level

## Customer & Revenue Performance Analysis

This folder contains the Intermediate Level submission for the ShadowFox Data Analyst internship.

### Files

- `dataset.csv` — cleaned transaction dataset used by the analysis.
- `analysis.ipynb` — reproducible Python/Jupyter analysis.
- `analysis_report.pdf` — structured business report containing metrics, findings and recommendations.

### Analysis coverage

- Data quality checks and preparation
- Exploratory analysis
- Customer behaviour and repeat-purchase analysis
- Product performance
- Revenue analysis
- Customer-segment performance
- Regional comparison
- Acquisition-channel analysis
- Monthly trend analysis
- Business insights
- Decision-oriented recommendations

### Dataset note

The dataset is synthetic and was created for educational/internship demonstration purposes. It is not presented as real company data.

### Run the notebook

Place `dataset.csv` and `analysis.ipynb` in the same directory, open the notebook in Jupyter, and run the cells from top to bottom.
